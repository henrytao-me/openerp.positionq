openerp.widget_ekiteditor = function(instance){
	instance.web.form.widgets.add('ekiteditor_filebrowse', 'instance.web.form.ekiteditor_filebrowse');
	instance.web.form.ekiteditor_filebrowse = instance.web.form.AbstractField.extend(instance.web.form.ReinitializeFieldMixin, {
	    template: 'ekiteditor_filebrowse',
	    widget_class: 'oe_form_field_char',
	    events: {
	        'change input': 'store_dom_value',
	    },
	    init: function (field_manager, node) {
	        this._super(field_manager, node);
	        this.password = this.node.attrs.password === 'True' || this.node.attrs.password === '1';
	    },
	    initialize_content: function() {
	        this.setupFocus(this.$('input'));
	        
	        if(!this.get('effective_readonly')){
	        	this.$('input').ekitfinder({
					url: 'web/widget_ekiteditor/index',
					lang: 'en',
					on_change: function(e){
						
					}
				});
	        }
	        
	        return;
	        
	        _this = this;
	        $('#btn_clickme').click(function(){
		        _this.rpc('web/vieterp/myfunction', {
		        	mydata: {
		        		a: 'a',
		        		b: 'b'
		        	}
		        }, {}).done(function(data){
		        	$.ekit.debug(data);	
		        });	
	        });
	        
	        
	        return;
	        $.ekit.debug($('#myid').html());
	        //test
	        this.rpc('web/vieterp/load', {
	        	action_id: 156,
	        	testvar: 'test',
	        }, {}).done(function(e){
	        	$.ekit.debug(e);	
	        });
	    },
	    store_dom_value: function () {
	        if (!this.get('effective_readonly')
	                && this.$('input').length
	                && this.is_syntax_valid()) {
	            this.internal_set_value(
	                this.parse_value(
	                    this.$('input').val()));
	        }
	    },
	    commit_value: function () {
	        this.store_dom_value();
	        return this._super();
	    },
	    render_value: function() {
	        var show_value = this.format_value(this.get('value'), '');
	        if (!this.get("effective_readonly")) {
	            this.$el.find('input').val(show_value);
	        } else {
	            if (this.password) {
	                show_value = new Array(show_value.length + 1).join('*');
	            }
	            this.$(".oe_form_char_content").text(show_value);
	        }
	    },
	    is_syntax_valid: function() {
	        if (!this.get("effective_readonly") && this.$("input").size() > 0) {
	            try {
	                this.parse_value(this.$('input').val(), '');
	                return true;
	            } catch(e) {
	                return false;
	            }
	        }
	        return true;
	    },
	    parse_value: function(val, def) {
	        return instance.web.parse_value(val, this, def);
	    },
	    format_value: function(val, def) {
	        return instance.web.format_value(val, this, def);
	    },
	    is_false: function() {
	        return this.get('value') === '' || this._super();
	    },
	    focus: function() {
	        this.$('input:first')[0].focus();
	    },
	    set_dimensions: function (height, width) {
	        this._super(height, width);
	        this.$('input').css({
	            height: height,
	            width: width
	        });
	    }
	});
}
