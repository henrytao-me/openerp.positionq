Require:
- jQuery-1.6.1 or above
- jQuery-ui-1.8.13 or above
- ekit.js

Inherit from:
- http://elrte.org/ - version 1.3
- http://elfinder.org/ - version 2.0