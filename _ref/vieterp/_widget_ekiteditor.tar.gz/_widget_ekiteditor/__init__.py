import werkzeug.wrappers
import werkzeug.datastructures
from openerp.addons.web import http as openerpweb
from . server.controller import handler as widget_ekiteditor_handler

class Widget_EkitEditor(openerpweb.Controller):
    _cp_path = "/web/widget_ekiteditor"

    @openerpweb.httprequest
    def index(self, req, **kwargs):
        
#        form = cgi.FieldStorage()
#        print type(form)
        
##        request = werkzeug.wrappers.Request(req.httprequest.environ)
#        req.httprequest.parameter_storage_class = werkzeug.datastructures.ImmutableMultiDict
#        
#        request = werkzeug.wrappers.BaseRequest(req.httprequest.environ)
#        
#        print '-----------------------------aaaaaaaaaaaa'
##        print request.files
#        print '-----------------------------aaaaaaaaaaaa'

        
        return widget_ekiteditor_handler(req, kwargs)
