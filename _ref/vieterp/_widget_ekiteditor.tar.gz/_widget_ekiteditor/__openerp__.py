{
    'name': "Widget Ekit Editor",
    'author': "Henry Tao",
    'category': 'Vieterp',
    'description': """
    Widget File Manager for VietERP
    """,
    'depends': ['web', 'vieterp_web'],
    'js': [
        'static/lib/ekiteditor/ekiteditor.js',
        'static/src/js/js.js',        
    ],
    'css': [
        'static/lib/ekiteditor/ekiteditor.css',
    ],
    'qweb': ['static/src/xml/xml.xml'],
    'auto_install': False,
}
