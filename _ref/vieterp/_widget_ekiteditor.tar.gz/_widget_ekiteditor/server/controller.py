#
# elFinder
# Python/OpenERP connector script
# By Henry Tao - http://hungtaoquang.com
#
import json
from ekiteditor.connector import *

def handler(req, args = {}):
    res = {}
    #get args
    cmd = ''
    try:
        cmd = args['cmd']
        del args['cmd']
    except KeyError:
        cmd = ''
    try:
        del args['_']
        del args['answer']
    except KeyError:
        pass
    #create finder
    
    
    
    connector = EkitEditorConnector(ls.ELFINDER_CONNECTOR_OPTION_SETS['default'])
    
    cmd, args = connector._fix_arg(cmd, args)
    print ''
    print ''
    print cmd, {}.fromkeys(args), type(args.get('upload[]', {}))
    print ''
    print ''
    
    res = connector.execute(cmd, **args)    
    res = json.dumps(res)
    #output
    return res
    
