# -*- coding: utf-8 -*-

from openerp.osv import osv, fields
from openerp.tools.translate import _
import logging
from datetime import datetime
from openerp.osv.fields import datetime as datetime_field
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from unidecode import unidecode
import types
from warnings import catch_warnings

class pq_vi_tri_yeu_to(osv.osv):
    
    def func_type(self, cr, uid, ids, fields, args, context=None):
        res = {}
        flow = [['vi_tri', 'yeu_to', 'tieu_chi', 'tcc1', 'tcc2'],
                ['vi_tri', 'yeu_to', 'tieu_chi', 'tcc1'],
                ['vi_tri', 'yeu_to', 'tieu_chi'],
                ['vi_tri', 'yeu_to']]
        for obj in self.read(cr, uid, ids, ['vi_tri', 'yeu_to', 'tieu_chi', 'tcc1', 'tcc2']):
            value = ''
            for f in flow:
                is_flow = True
                for sf in f:
                    if not obj[sf]:
                        is_flow = False
                        break
                if is_flow == True:
                    value = '.'.join(f)
                    break
            res[obj['id']] = value
        return res
    
    def func_diem(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['name']):
            res[obj['id']] = 0
        return res
    
    def func_tieu_chi_trong_so(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['name']):
            res[obj['id']] = 0
        return res
    
    def func_tieu_chi_tcc1_trong_so(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['name']):
            res[obj['id']] = 0
        return res
    
    _name = 'pq.vi.tri.yeu.to'
    _description = 'Nhom vi tri - Yeu to'
    _columns = {
        'name': fields.char('Tên', size=128),
        'vi_tri': fields.many2one('pq.vi.tri', string="Vị trí", ondelete="cascade"),
        'yeu_to': fields.many2one('pq.yeu.to', string="Yếu tố", ondelete="cascade"),
        'tieu_chi': fields.many2one('pq.tieu.chi', string="Tiêu chí", ondelete="cascade"),
        'tcc1': fields.many2one('pq.tcc1', string="Tiêu chí cấp 1", ondelete="cascade"),
        'tcc2': fields.many2one('pq.tcc2', string="Tiêu chí cấp 2", ondelete="cascade"),
        
        'type': fields.function(func_type, method=True, string="Type", type="char", size=128, store=True),
        
        # vi tri - yeu to
        'diem': fields.function(func_diem, method=True, string="Điểm", type="float", digits=(16,2)),
        
        # vi tri - yeu to - tieu chi
        'tieu_chi_trong_so': fields.function(func_tieu_chi_trong_so, string="Trọng số", type="float", digits=(16,2), multi=True),
        'tieu_chi_muc_do': fields.function(func_tieu_chi_trong_so, string="Mức độ", type="float", digits=(16,2), multi=True),
        'tieu_chi_diem': fields.function(func_tieu_chi_trong_so, string="Điểm", type="float", digits=(16,2), multi=True),
        
        # vi tri - yeu to - tieu chi - tcc1
        'tieu_chi_tcc1_trong_so': fields.function(func_tieu_chi_tcc1_trong_so, string="Trọng số", type="float", digits=(16,2)),
        
        # vi tri - yeu to - tieu chi - tcc1 - tcc2
        'tieu_chi_tcc1_tcc2_trong_so': fields.float('Trọng số', digits=(16,2)), 
        
        'create_date': fields.datetime('Ngày giờ tạo', readonly=True),
        'user_id': fields.many2one('res.users', string="Người tạo", readonly=True),
    }
    _defaults = {
        'tieu_chi_tcc1_tcc2_trong_so': lambda self, cr, uid, context = None: 0,
        'user_id': lambda self, cr, uid, context = None: uid
    }
    _sql_constraints = [
        ('_unique', 'unique(vi_tri, yeu_to, tieu_chi, tcc1, tcc2)', 'record is unique')
    ]
    
    def auto_sync(self, cr, uid, vi_tri_id=None, yeu_to_id=None):
        if not vi_tri_id and not yeu_to_id:
            return
        elif vi_tri_id:
            yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
            for xid in yeu_to_ids: 
                self.create(cr, uid, {'vi_tri': vi_tri_id,
                                       'yeu_to': xid})
        else: 
            vi_tri_ids = self.pool.get('pq.vi.tri').search(cr, uid, [])
            for xid in vi_tri_ids:
                self.create(cr, uid, {'vi_tri': xid,
                                      'yeu_to': yeu_to_id})
        return
    
    def obj2dict(self, cr, uid, obj, keys=[]):
        res = {}
        if len(keys) == 0:
            return res
        item = keys.pop(0)        
        for o in obj:
            if len(keys) == 0:
                res[o[item][0]] = o
            else:
                tmp = []
                for to in obj:
                    if to[item][0] == o[item][0]:
                        tmp.append(to)
                res[o[item][0]] = self.obj2dict(cr, uid, tmp[:], keys[:])
        return res
        
pq_vi_tri_yeu_to()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

