# -*- coding: utf-8 -*-

from openerp.osv import osv, fields
from openerp.tools.translate import _
import logging
from datetime import datetime
from openerp.osv.fields import datetime as datetime_field
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from unidecode import unidecode
import types
from warnings import catch_warnings

class pq_nhom_vi_tri_yeu_to(osv.osv):
    
    def func_trong_so(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['nhom_vi_tri', 'yeu_to']):
            value = 0
            tids = self.search(cr, uid, [('nhom_vi_tri', '=', obj['nhom_vi_tri'][0]),
                                         ('yeu_to', '=', obj['yeu_to'][0]),
                                         ('model', '=', 'pq.yeu.to')])
            for tobj in self.read(cr, uid, tids, ['yeu_to_trong_so']):
                value += tobj['yeu_to_trong_so']
            res[obj['id']] = value
        return res
    
    def func_ty_trong(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['nhom_vi_tri', 'yeu_to', 'trong_so']):
            value = obj['trong_so']
            total = 0
            tids = self.search(cr, uid, [('nhom_vi_tri', '=', obj['nhom_vi_tri'][0]),
                                         ('model', '=', '')])
            for tobj in self.read(cr, uid, tids, ['trong_so']):
                total += tobj['trong_so']
            if total == 0:
                value = 0
            else:
                value = value * 1.0 / total
            res[obj['id']] = value
        return res
    
    def func_tieu_chi_ty_trong(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for obj in self.read(cr, uid, ids, ['nhom_vi_tri', 'yeu_to', 'ty_trong', 'tieu_chi_trong_so']):
            value = 0
            total = 0
            tids = self.search(cr, uid, [('nhom_vi_tri', '=', obj['nhom_vi_tri'][0]),
                                         ('yeu_to', '=', obj['yeu_to'][0]),
                                         ('model', '=', 'pq.tieu.chi')])
            for tobj in self.read(cr, uid, tids, ['tieu_chi_trong_so']):
                total += tobj['tieu_chi_trong_so']
            if total == 0:
                value = 0
            else:
                value = obj['tieu_chi_trong_so'] * 1.0 / total * obj['ty_trong']
            res[obj['id']] = value
        return res
    
    _name = 'pq.nhom.vi.tri.yeu.to'
    _description = 'Nhom vi tri - Yeu to'
    _columns = {
        'name': fields.char('Tên', size=128),
        'nhom_vi_tri': fields.many2one('pq.nhom.vi.tri', string="Nhóm vị trí", ondelete="cascade"),
        'yeu_to': fields.many2one('pq.yeu.to', string="Yếu tố", ondelete="cascade"),
        'model': fields.char('Model', size=128),
        'key': fields.char('Key', size=128),
        
        # nhom vi tri - yeu to
        'trong_so': fields.function(func_trong_so, method=True, string='Trọng số', type="float", digits=(16, 2)),
        'ty_trong': fields.function(func_ty_trong, method=True, string='Tỷ trọng', type="float", digits=(16, 2)),
        
        # nhom vi tri - yeu to - yeu to 
        'yeu_to_trong_so': fields.float('Trọng số', digits=(16, 2)),
        
        # nhom vi tri - yeu to - tieu chi 
        'tieu_chi_trong_so': fields.float('Trọng số', digits=(16, 2)),
        'tieu_chi_ty_trong': fields.function(func_tieu_chi_ty_trong, method=True, string="Tỷ trọng", type="float", digits=(16,2)),
        
        # nhom vi tri - yeu to - tieu chi - bac
        'tieu_chi_bac_trong_so': fields.float('Trọng số', digits=(16, 2)),
        
        'create_date': fields.datetime('Ngày giờ tạo', readonly=True),
        'user_id': fields.many2one('res.users', string="Người tạo", readonly=True),
    }
    _defaults = {
        'model': lambda self, cr, uid, context = None: '',
        'yeu_to_trong_so': lambda self, cr, uid, context = None: 0,
        'tieu_chi_trong_so': lambda self, cr, uid, context = None: 0,
        'tieu_chi_bac_trong_so': lambda self, cr, uid, context = None: 0,
        'user_id': lambda self, cr, uid, context = None: uid
    }
    _sql_constraints = [
        ('name_uniq', 'unique(nhom_vi_tri, yeu_to, model, key)', 'record is unique'),
    ]
    
    def create_nhom_vi_tri_yeu_to(self, cr, uid, nhom_vi_tri_id=None, yeu_to_id=None):
        if not nhom_vi_tri_id and not yeu_to_id:
            return
        elif nhom_vi_tri_id:
            yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
            for xid in yeu_to_ids: 
                self.create(cr, uid, {'nhom_vi_tri': nhom_vi_tri_id,
                                       'yeu_to': xid})
                for yid in yeu_to_ids: 
                    self.create(cr, uid, {'nhom_vi_tri': nhom_vi_tri_id,
                                           'yeu_to': xid,
                                           'model': 'pq.yeu.to',
                                           'key': yid}) 
        else: 
            nhom_vi_tri_ids = self.pool.get('pq.nhom.vi.tri').search(cr, uid, [])
            yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
            for xid in nhom_vi_tri_ids:
                self.create(cr, uid, {'nhom_vi_tri': xid,
                                      'yeu_to': yeu_to_id})
                for yid in yeu_to_ids:
                    if yid == yeu_to_id:
                        continue
                    self.create(cr, uid, {'nhom_vi_tri': xid,
                                          'yeu_to': yid,
                                          'model': 'pq.yeu.to',
                                          'key': yeu_to_id})
                for yid in yeu_to_ids:
                    self.create(cr, uid, {'nhom_vi_tri': xid,
                                          'yeu_to': yeu_to_id,
                                          'model': 'pq.yeu.to',
                                          'key': yid})        
        return 
    
    def get_yeu_to_matrix(self, cr, uid, nhom_vi_tri_id):
        res = {'yeu_to': [],
               'matrix': {},
               'data': {}}
        # get yeu to
        yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
        res['yeu_to'] = self.pool.get('pq.yeu.to').read(cr, uid, yeu_to_ids, ['name'])
        res['yeu_to'].sort(key=lambda x: x['id'])
        # get matrix
        ids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id), ('model', '=', 'pq.yeu.to')])
        for obj in self.read(cr, uid, ids, ['yeu_to', 'key', 'yeu_to_trong_so']):
            if not res['matrix'].get(obj['yeu_to'][0]):
                res['matrix'][obj['yeu_to'][0]] = {}
            res['matrix'][obj['yeu_to'][0]][obj['key']] = {'id': obj['id'],
                                                           'value': obj['yeu_to_trong_so']}
        # get data
        ids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id), ('model', '=', '')])
        for obj in self.read(cr, uid, ids, ['yeu_to', 'trong_so', 'ty_trong']):
            res['data'][obj['yeu_to'][0]] = {'trong_so': obj['trong_so'],
                                             'ty_trong': obj['ty_trong']}
        return res
    
    def set_yeu_to_matrix(self, cr, uid, nhom_vi_tri_id, matrix):
        for x in matrix:
            for y in matrix[x]:
                value = 0
                if x < y:
                    try:
                        value = int(matrix[x][y]['value'])
                    except:
                        pass
                if x > y:
                    try:
                        value = 2 - int(matrix[y][x]['value'])
                    except: 
                        value = 2
                        pass
                self.write(cr, uid, matrix[x][y]['id'], {'yeu_to_trong_so': value})
        return
    
    def get_tieu_chi_matrix(self, cr, uid, nhom_vi_tri_id):
        res = {}
        # get yeu to tieu chi
        yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
        tieu_chi_ids = self.pool.get('pq.tieu.chi').search(cr, uid, [('yeu_to', 'in', yeu_to_ids)])
        yeu_to = {}
        for obj in self.pool.get('pq.tieu.chi').read(cr, uid, tieu_chi_ids, ['name', 'yeu_to']):
            if not yeu_to.get(obj['yeu_to'][0]):
                yeu_to[obj['yeu_to'][0]] = {'id': obj['yeu_to'][0],
                                            'name': obj['yeu_to'][1],
                                            'ty_trong': 0,
                                            'tieu_chi': {}}
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][obj['id']] = {'id': obj['id'],
                                                               'name': obj['name'],
                                                               'trong_so': 0,
                                                               'ty_trong': 0}  
       
        # get nhom vi tri - yeu to.ty trong
        tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                     ('model', '=', '')])
        for obj in self.read(cr, uid, tids, ['yeu_to', 'ty_trong']):
            yeu_to[obj['yeu_to'][0]]['ty_trong'] = obj['ty_trong']
        # get nhom vi tri - yeu to - tieu chi.tieu_chi_trong_so, tieu_chi_ty_trong
        tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                     ('model', '=', 'pq.tieu.chi')])
        for obj in self.read(cr, uid, tids, ['yeu_to', 'key', 'tieu_chi_trong_so', 'tieu_chi_ty_trong']):
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][int(obj['key'])]['trong_so'] = obj['tieu_chi_trong_so']
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][int(obj['key'])]['ty_trong'] = obj['tieu_chi_ty_trong']
        res = yeu_to
        return res
    
    def set_tieu_chi_matrix(self, cr, uid, nhom_vi_tri_id, yeu_to):
        # get bac
        tids = self.pool.get('pq.bac').search(cr, uid, [])
        bac = self.pool.get('pq.bac').read(cr, uid, tids, ['name'])
        # calculate yeu to
        for i in yeu_to:
            for j in yeu_to[i]['tieu_chi']:
                tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                             ('yeu_to', '=', yeu_to[i]['id']),
                                             ('model', '=', 'pq.tieu.chi'),
                                             ('key', '=', yeu_to[i]['tieu_chi'][j]['id'])])
                if not tids:
                    try:
                        self.create(cr, uid, {'nhom_vi_tri': nhom_vi_tri_id,
                                              'yeu_to': yeu_to[i]['id'],
                                              'model': 'pq.tieu.chi',
                                              'key': yeu_to[i]['tieu_chi'][j]['id'],
                                              'tieu_chi_trong_so': yeu_to[i]['tieu_chi'][j]['trong_so']})
                    except:
                        self.write(cr, uid, tids, {'tieu_chi_trong_so': yeu_to[i]['tieu_chi'][j]['trong_so']})
                else:
                    self.write(cr, uid, tids, {'tieu_chi_trong_so': yeu_to[i]['tieu_chi'][j]['trong_so']})
                
                # set bac
#                 for b in bac:
#                     tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
#                                                  ('yeu_to', '=', yeu_to[i]['id']),
#                                                  ('model', '=', 'pq.tieu.chi'),
#                                                  ('key', '=', yeu_to[i]['tieu_chi'][j]['id'])])
        return
    
    def get_tieu_chi_bac_matrix(self, cr, uid, nhom_vi_tri_id):
        res = {}
        # get yeu to tieu chi
        yeu_to_ids = self.pool.get('pq.yeu.to').search(cr, uid, [])
        tieu_chi_ids = self.pool.get('pq.tieu.chi').search(cr, uid, [('yeu_to', 'in', yeu_to_ids)])
        yeu_to = {}
        for obj in self.pool.get('pq.tieu.chi').read(cr, uid, tieu_chi_ids, ['name', 'yeu_to']):
            if not yeu_to.get(obj['yeu_to'][0]):
                yeu_to[obj['yeu_to'][0]] = {'id': obj['yeu_to'][0],
                                            'name': obj['yeu_to'][1],
                                            'ty_trong': 0,
                                            'tieu_chi': {}}
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][obj['id']] = {'id': obj['id'],
                                                               'name': obj['name'],
                                                               'trong_so': 0,
                                                               'ty_trong': 0,
                                                               'bac': {}}  
       
        # get nhom vi tri - yeu to.ty trong
        tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                     ('model', '=', '')])
        for obj in self.read(cr, uid, tids, ['yeu_to', 'ty_trong']):
            yeu_to[obj['yeu_to'][0]]['ty_trong'] = obj['ty_trong']
        # get nhom vi tri - yeu to - tieu chi.tieu_chi_trong_so, tieu_chi_ty_trong
        tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                     ('model', '=', 'pq.tieu.chi')])
        for obj in self.read(cr, uid, tids, ['yeu_to', 'key', 'tieu_chi_trong_so', 'tieu_chi_ty_trong']):
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][int(obj['key'])]['trong_so'] = obj['tieu_chi_trong_so']
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][int(obj['key'])]['ty_trong'] = obj['tieu_chi_ty_trong']
        # get bac
        tids = self.pool.get('pq.bac').search(cr, uid, [])
        bac = self.pool.get('pq.bac').read(cr, uid, tids, ['name'])
        # get nhom vi tri - yeu to - tieu chi - bac
        tids = self.search(cr, uid, [('nhom_vi_tri', '=', nhom_vi_tri_id),
                                     ('model', '=', 'pq.tieu.chi,pq.bac')])
        for obj in self.read(cr, uid, tids, ['yeu_to', 'key', 'tieu_chi_bac_trong_so']):
            yeu_to[obj['yeu_to'][0]]['tieu_chi'][int(obj[key].split(',')[0])]['bac'][int(obj[key].split(',')[1])] = {'id': int(obj[key].split(',')[1]),
                                                                                                                     'trong_so': obj['tieu_chi_bac_trong_so']}
        res = {'yeu_to': yeu_to,
               'bac': bac}
        return res
    
pq_nhom_vi_tri_yeu_to()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

