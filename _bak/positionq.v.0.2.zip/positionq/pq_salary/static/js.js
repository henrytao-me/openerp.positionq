openerp.pq_salary = function(instance) {

	var QWeb = instance.web.qweb;

	/*
	 * custom widget
	 */
	var template = instance.web.form.AbstractField.extend(instance.web.form.ReinitializeFieldMixin, {
		template: 'pq_salary_w1',
		_t: {
			table: '.custom'
		},
		data: null,
		id: null,

		init: function() {
			this._super.apply(this, arguments);
		},

		get: function(key) {
			return key === 'readonly' ? false : this._super.apply(this, arguments);
		},

		get_t: function(key) {
			return this.template + this._t[key];
		},

		render_value: function() {
			var self = this;
			self._super();
			self.id = self.view.dataset.ids[self.view.dataset.index];
		}
	});

	/*
	 * pq_salary_w1
	 */

	instance.web.form.widgets.add('pq_salary_w1', 'instance.web.form.pq_salary_w1');
	instance.web.form.pq_salary_w1 = template.extend({
		template: 'pq_salary_w1',
		saved: true,

		render_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			if(self.saved !== true) {
				return;
			};
			// get data from server
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('get_yeu_to_matrix', [self.id]).then(function(res, status) {
				// store data
				self.data = res.data;
				// render template
				var $table = $(instance.web.qweb.render(self.get_t('table')));
				ngApp.controller(self.template, function($scope) {
					$scope.res = res;
					$scope.widget = self;
					$scope.check = function(a, b, formula) {
						if(formula == 'g') {
							return a > b;
						};
						if(formula == 'l') {
							return a < b;
						};
						if(formula == 'e') {
							return a == b;
						};
						return false;
					};
					$scope.percent = function(value) {
						return (parseInt(Math.round(value, 4) * 10000) / 100) + '%';
					}
				});
				angular.bootstrap($table[0], ['ngApp']);
				self.$el.empty().append($table);
			});
		},

		commit_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			if(self.saved !== true){
				return;
			};
			self.saved = false;
			model.call('set_yeu_to_matrix', [self.id, self.data]).then(function(res, status) {
				self.saved = true;
				self.render_value();
			});
		}
	});
	
	/*
	 * pq_salary_w2
	 */

	instance.web.form.widgets.add('pq_salary_w2', 'instance.web.form.pq_salary_w2');
	instance.web.form.pq_salary_w2 = template.extend({
		template: 'pq_salary_w2',
		saved: true,

		render_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			if(self.saved !== true) {
				return;
			};
			// get data from server
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('get_tieu_chi_matrix', [self.id]).then(function(res, status) {
				// store data
				self.data = res;
				// render template
				var $table = $(instance.web.qweb.render(self.get_t('table')));
				ngApp.controller(self.template, function($scope) {
					$scope.res = res;
					$scope.widget = self;
					$scope.percent = function(value) {
						return (parseInt(Math.round(value, 4) * 10000) / 100) + '%';
					},
					$scope.length = function(obj){
						var len = Object.keys(obj).length;						
						return len == 0 ? 1 : len;
					}
				});
				angular.bootstrap($table[0], ['ngApp']);
				self.$el.empty().append($table);
			});
		},

		commit_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			if(self.saved !== true){
				return;
			};
			self.saved = false;
			model.call('set_tieu_chi_matrix', [self.id, self.data]).then(function(res, status) {
				self.saved = true;
				self.render_value();
			});
		}
	});

	/*
	 * pq_salary_w3
	 */

	instance.web.form.widgets.add('pq_salary_w3', 'instance.web.form.pq_salary_w3');
	instance.web.form.pq_salary_w3 = template.extend({
		template: 'pq_salary_w3',
		saved: true,

		render_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			if(self.saved !== true) {
				return;
			};
			// get data from server
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('get_tieu_chi_bac_matrix', [self.id]).then(function(res, status) {
				// store data
				self.data = res;
				// render template
				var $table = $(instance.web.qweb.render(self.get_t('table')));
				ngApp.controller(self.template, function($scope) {
					$scope.res = res;
					$scope.widget = self;
					$scope.percent = function(value) {
						return (parseInt(Math.round(value, 4) * 10000) / 100) + '%';
					},
					$scope.length = function(obj){
						var len = Object.keys(obj).length;						
						return len == 0 ? 1 : len;
					}
				});
				angular.bootstrap($table[0], ['ngApp']);
				self.$el.empty().append($table);
			});
		},

		commit_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			if(self.saved !== true){
				return;
			};
			self.saved = false;
			model.call('set_tieu_chi_matrix', [self.id, self.data]).then(function(res, status) {
				self.saved = true;
				self.render_value();
			});
		}
	});


};
