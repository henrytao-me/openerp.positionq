openerp.pq_salary = function(instance) {

	var QWeb = instance.web.qweb;

	/*
	 * custom widget
	 */
	var template = instance.web.form.AbstractField.extend(instance.web.form.ReinitializeFieldMixin, {
		template: 'pq_salary_w1',
		_t: {
			table: '.custom'
		},
		data: null,
		id: null,

		init: function() {
			this._super.apply(this, arguments);
		},

		get: function(key) {
			return key === 'readonly' ? false : this._super.apply(this, arguments);
		},
		
		get_t: function(key){
			return this.template + this._t[key];
		},

		render_value: function() {
			var self = this;
			self._super();
			self.id = self.view.dataset.ids[self.view.dataset.index];
		}
	});

	instance.web.form.widgets.add('pq_salary_w1', 'instance.web.form.pq_salary_w1');
	instance.web.form.pq_salary_w1 = template.extend({
		template: 'pq_salary_w1',
		saved: true,

		render_value: function() {
			console.log('b');
			var self = this;
			self._super.apply(self, arguments);
			if(self.saved !== true){
				return;
			};
			// get data from server
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('get_yeu_to_matrix', [self.id]).then(function(res, status) {
				// store data
				self.data = res.matrix;
				// render template
				var $table = $(instance.web.qweb.render(self.get_t('table')));
				ngApp.controller(self.template, function($scope) {
					$scope.res = res;
					$scope.widget = self;
					$scope.check = function(a, b, formula) {
						if(formula == 'g') {
							return a > b;
						};
						if(formula == 'l') {
							return a < b;
						};
						if(formula == 'e') {
							return a == b;
						};
						return false;
					};
					$scope.percent = function(value) {
						return (parseInt(Math.round(value, 4) * 10000) / 100) + '%';
					}
				});
				angular.bootstrap($table[0], ['ngApp']);
				self.$el.empty().append($table);
			});
		},

		commit_value: function() {
			var self = this;
			self._super.apply(self, arguments);
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			self.saved = false;
			model.call('set_yeu_to_matrix', [self.id, self.data]).then(function(res, status) {
				self.saved = true;
				self.render_value();
			});
		}
	});

	return;
	/*
	 * widget pq_salary_w1
	 */
	instance.web.form.widgets.add('pq_salary_w1', 'instance.web.form.pq_salary_w1');
	instance.web.form.pq_salary_w1 = instance.web.form.AbstractField.extend(instance.web.form.ReinitializeFieldMixin, {
		template: 'pq_salary_w1',
		_t: {
			table: 'pq_salary_w1.custom'
		},
		data: null,
		id: null,

		get: function(key) {
			return key === 'readonly' ? false : this._super.apply(this, arguments);
		},

		render_value: function() {

			console.log(arguments);

			var self = this;
			self._super.apply(self, arguments);
			self.id = self.view.dataset.ids[self.view.dataset.index];
			// get data from server
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('get_yeu_to_matrix', [self.id]).then(function(res, status) {
				// store data
				self.data = res.matrix;
				// render template
				var $table = $(instance.web.qweb.render(self._t.table));
				ngApp.controller(self.template, function($scope) {
					$scope.res = res;
					$scope.widget = self;
					$scope.check = function(a, b, formula) {
						if(formula == 'g') {
							return a > b;
						};
						if(formula == 'l') {
							return a < b;
						};
						if(formula == 'e') {
							return a == b;
						};
						return false;
					};
					$scope.percent = function(value) {
						return (parseInt(Math.round(value, 4) * 10000) / 100) + '%';
					}
				});
				angular.bootstrap($table[0], ['ngApp']);
				self.$el.empty().append($table);
			});
		},

		commit_value: function() {
			var self = this;
			var model = new instance.web.Model('pq.nhom.vi.tri.yeu.to');
			model.call('set_yeu_to_matrix', [self.id, self.data]).then(function(res, status) {
			});
		}
	});

};
